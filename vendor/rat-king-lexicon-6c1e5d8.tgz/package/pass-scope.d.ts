import { Effect } from "effect";
export declare const scopeWithin: (passScope: readonly string[], issuerScope: readonly string[]) => Effect.Effect<void, import("./trust-failure.js").TrustFailure, never>;
export declare const grantableScope: (scopes: readonly string[], grantable: ReadonlySet<string>) => Effect.Effect<void, import("./trust-failure.js").TrustFailure, never>;
