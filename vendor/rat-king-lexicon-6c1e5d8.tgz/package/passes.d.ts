import { Effect, Schema } from "effect";
import { NonceBinding } from "./pass-bindings.js";
import * as Pass from "./src/edge.pass.js";
import * as Ticket from "./src/edge.ticket.js";
import type { LexValue } from "./src/runtime.js";
import type { Issuer } from "./trust-authority.js";
import type { TrustFailure } from "./trust-failure.js";
import { Signatures } from "./trust-signatures.js";
import type { PublicKeyValue } from "./trust.js";
export { decodeDidKey } from "./did-key.js";
export { makeMemoryNonceBinding, makeMemoryRunBinding, NonceBinding, RunBinding, } from "./pass-bindings.js";
export type { NonceIdentity, RunToken } from "./pass-bindings.js";
export { scopeWithin } from "./pass-scope.js";
export type TicketValue = typeof Ticket.Main.Type;
export type PassValue = typeof Pass.Main.Type;
export interface SigningKey {
    readonly publicKey: PublicKeyValue;
    readonly sign: (bytes: Uint8Array) => Effect.Effect<string, TrustFailure>;
}
export declare const SignedTicket: Schema.Struct<{
    readonly publicKey: Schema.Struct<{
        readonly crv: Schema.Literal<"P-256">;
        readonly kty: Schema.Literal<"EC">;
        readonly x: Schema.String;
        readonly y: Schema.String;
    }>;
    readonly record: Schema.StructWithRest<Schema.Struct<{
        readonly $type: Schema.Literal<"sh.ratking.ticket">;
        readonly did: Schema.brand<Schema.String, "Lexicon:did">;
        readonly exp: Schema.Int;
        readonly fingerprint: Schema.String;
        readonly iat: Schema.Int;
        readonly issuer: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Codec<LexValue, import("./src/runtime.js").LexJson, never, never>>]>;
    readonly signature: Schema.String;
}>;
export declare const SignedPass: Schema.Struct<{
    readonly record: Schema.StructWithRest<Schema.Struct<{
        readonly $type: Schema.Literal<"sh.ratking.pass">;
        readonly desk: Schema.String;
        readonly deskDid: Schema.brand<Schema.String, "Lexicon:did">;
        readonly exp: Schema.Int;
        readonly iat: Schema.Int;
        readonly nonce: Schema.String;
        readonly run: Schema.String;
        readonly scope: Schema.$Array<Schema.String>;
        readonly v: Schema.Literal<1>;
        readonly worker: Schema.brand<Schema.String, "Lexicon:did">;
    }>, readonly [Schema.$Record<Schema.String, Schema.Codec<LexValue, import("./src/runtime.js").LexJson, never, never>>]>;
    readonly signature: Schema.String;
}>;
export declare const signTicket: (issuerKey: SigningKey, input: LexValue, deskKey?: {
    readonly crv: "P-256";
    readonly kty: "EC";
    readonly x: string;
    readonly y: string;
} | undefined) => Effect.Effect<{
    publicKey: {
        readonly crv: "P-256";
        readonly kty: "EC";
        readonly x: string;
        readonly y: string;
    };
    record: {
        readonly [x: string]: LexValue;
        readonly $type: "sh.ratking.ticket";
        readonly did: string & import("effect/Brand").Brand<"Lexicon:did">;
        readonly exp: number;
        readonly fingerprint: string;
        readonly iat: number;
        readonly issuer: string;
        readonly name: string;
        readonly namespace: string;
    };
    signature: string;
}, TrustFailure, never>;
export declare const signPass: (deskKey: SigningKey, input: LexValue) => Effect.Effect<{
    record: {
        readonly [x: string]: LexValue;
        readonly $type: "sh.ratking.pass";
        readonly desk: string;
        readonly deskDid: string & import("effect/Brand").Brand<"Lexicon:did">;
        readonly exp: number;
        readonly iat: number;
        readonly nonce: string;
        readonly run: string;
        readonly scope: readonly string[];
        readonly v: 1;
        readonly worker: string & import("effect/Brand").Brand<"Lexicon:did">;
    };
    signature: string;
}, TrustFailure, never>;
export declare const signRequest: (workerKey: SigningKey, request: Uint8Array) => Effect.Effect<string, TrustFailure, never>;
export declare const verifyTicket: (pinnedIssuers: ReadonlyMap<string, Issuer>, input: LexValue, now: number) => Effect.Effect<{
    key: {
        readonly crv: "P-256";
        readonly kty: "EC";
        readonly x: string;
        readonly y: string;
    };
    record: {
        readonly [x: string]: LexValue;
        readonly $type: "sh.ratking.ticket";
        readonly did: string & import("effect/Brand").Brand<"Lexicon:did">;
        readonly exp: number;
        readonly fingerprint: string;
        readonly iat: number;
        readonly issuer: string;
        readonly name: string;
        readonly namespace: string;
    };
}, TrustFailure, Signatures>;
export interface KnownDesk {
    readonly did: string;
    readonly key: PublicKeyValue;
    readonly name: string;
}
export type DeskAuthority = {
    readonly knownDesk: KnownDesk;
} | {
    readonly pinnedIssuers: ReadonlyMap<string, Issuer>;
    readonly ticket: LexValue;
};
export type PassAuthority = DeskAuthority & {
    readonly grantable: ReadonlySet<string>;
    readonly issuerScope: readonly string[];
};
declare const verified: unique symbol;
export interface VerifiedPass {
    readonly [verified]: true;
    readonly record: PassValue;
    readonly workerKey: PublicKeyValue;
}
export declare const verifyPass: (authority: PassAuthority, input: LexValue, now: number) => Effect.Effect<VerifiedPass, TrustFailure, NonceBinding | Signatures>;
export declare const verifyRequest: (pass: VerifiedPass, request: Uint8Array<ArrayBufferLike>, signed: string) => Effect.Effect<void, TrustFailure, Signatures>;
