import { TrustFailure } from "./trust-failure.js";
export declare const refusal: (what: string, why: string, next: string) => TrustFailure;
