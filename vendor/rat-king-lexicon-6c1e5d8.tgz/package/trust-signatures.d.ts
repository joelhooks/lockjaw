import { Context } from "effect";
import type { Effect } from "effect";
import type { TrustFailure } from "./trust-failure.js";
import type { PublicKeyValue } from "./trust.js";
declare const Signatures_base: Context.ServiceClass<Signatures, "ratking/Signatures", {
    readonly verify: (key: PublicKeyValue, bytes: Uint8Array, signature: string) => Effect.Effect<boolean, TrustFailure>;
    readonly digest: (bytes: Uint8Array) => Effect.Effect<string, TrustFailure>;
}>;
export declare class Signatures extends Signatures_base {
}
export {};
