import { Schema } from "effect";
import * as Defs from "./defs.js";
import * as Runtime from "./runtime.js";
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({
    critical: Schema.optionalKey(Schema.Boolean),
    envelope: Defs.EncryptedEnvelope,
    generation: Schema.optionalKey(Schema.Int.check(Schema.isGreaterThanOrEqualTo(1), Schema.isLessThanOrEqualTo(9_007_199_254_740_991))),
    leaseId: Schema.optionalKey(Runtime.lexString({ format: "tid", type: "string" }).pipe(Schema.brand("Lexicon:tid"))),
    wakeReason: Schema.optionalKey(Runtime.lexString({
        enum: ["to", "ask", "reply", "cc", "quiet", "data"],
        type: "string",
    }).pipe(Schema.decodeTo(Schema.Literals(["to", "ask", "reply", "cc", "quiet", "data"])))),
    woke: Schema.optionalKey(Schema.Boolean),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Schema.StructWithRest(Schema.Struct({ receipt: Defs.Receipt }), [Schema.Record(Schema.String, Runtime.Data)]);
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "LeaseMismatch",
    "Retired",
    "InvalidRequest",
    "AuthRequired",
    "Forbidden",
    "Conflict",
    "UnsupportedEnvelope",
    "MailboxUnavailable",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.mailbox.send",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.mailbox.send",
};
