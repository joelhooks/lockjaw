import { Effect, Schema } from "effect";
import * as DeskDefs from "./desk.defs.js";
import * as Query from "./query.js";
import * as Runtime from "./runtime.js";
export const Params = Schema.StructWithRest(Schema.Struct({
    desk: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Input = Schema.Undefined;
export const Output = Schema.StructWithRest(Schema.Struct({
    covered: Schema.Array(Runtime.lexString({ maxLength: 512, type: "string" })).check(Schema.isMinLength(0), Schema.isMaxLength(200)),
    digest: Schema.Array(DeskDefs.Queued).check(Schema.isMinLength(0), Schema.isMaxLength(200)),
    mentions: Schema.Array(DeskDefs.Queued).check(Schema.isMinLength(0), Schema.isMaxLength(200)),
    more: Schema.Boolean,
    oldestQuietAgeMs: Schema.optionalKey(Schema.Int.check(Schema.isGreaterThanOrEqualTo(0), Schema.isLessThanOrEqualTo(9_007_199_254_740_991))),
    oldestQuietAt: Schema.optionalKey(Runtime.lexString({ format: "datetime", type: "string" }).pipe(Schema.brand("Lexicon:datetime"))),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const ParamsFromQuery = Schema.StructWithRest(Schema.Struct({ desk: Schema.String }), [Schema.Record(Schema.String, Runtime.Data)]).pipe(Schema.decodeTo(Params));
export const encodeParams = Effect.fn("lexicon.encodeParams")(function* encodeParams(params) {
    return Query.entries(yield* Schema.decodeUnknownEffect(Query.Params)(yield* Schema.encodeEffect(ParamsFromQuery)(params)));
});
export const decodeParams = Effect.fn("lexicon.decodeParams")(function* decodeParams(entries) {
    return yield* Schema.decodeUnknownEffect(ParamsFromQuery)(Query.parameters(entries));
});
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "AuthRequired",
    "Forbidden",
    "MailboxUnavailable",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "",
    method: "GET",
    nsid: "sh.mschf.ratking.desk.pending",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.desk.pending",
};
