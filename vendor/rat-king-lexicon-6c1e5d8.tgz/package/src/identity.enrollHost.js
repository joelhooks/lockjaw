import { Schema } from "effect";
import * as Defs from "./defs.js";
import * as Runtime from "./runtime.js";
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({ document: Defs.DidDocument }), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Schema.StructWithRest(Schema.Struct({
    did: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "AuthRequired",
    "Forbidden",
    "DocumentConflict",
    "MailboxUnavailable",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.identity.enrollHost",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.identity.enrollHost",
};
