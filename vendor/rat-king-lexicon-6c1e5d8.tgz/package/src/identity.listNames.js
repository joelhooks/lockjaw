import { Effect, Schema } from "effect";
import * as Defs from "./defs.js";
import * as Query from "./query.js";
import * as Runtime from "./runtime.js";
export const Parent = Schema.StructWithRest(Schema.Struct({
    name: Runtime.lexString({ maxLength: 128, type: "string" }).check(Schema.isPattern(/^(?:[a-z0-9]+(?:-[a-z0-9]+)*\/)?[a-z][a-z0-9_-]{0,31}$/u)),
    session: Runtime.lexString({ minLength: 1, type: "string" }),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Entry = Schema.StructWithRest(Schema.Struct({
    did: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
    document: Defs.DidDocument,
    name: Runtime.lexString({ maxLength: 128, type: "string" }),
    parent: Schema.optionalKey(Parent),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Params = Schema.StructWithRest(Schema.Struct({
    cursor: Schema.optionalKey(Runtime.lexString({ maxLength: 128, type: "string" })),
    limit: Schema.optionalKey(Schema.Int.check(Schema.isGreaterThanOrEqualTo(1), Schema.isLessThanOrEqualTo(100))),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Input = Schema.Undefined;
export const Output = Schema.StructWithRest(Schema.Struct({
    cursor: Schema.optionalKey(Runtime.lexString({ maxLength: 128, type: "string" })),
    names: Schema.Array(Entry).check(Schema.isMinLength(0), Schema.isMaxLength(100)),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const ParamsFromQuery = Schema.StructWithRest(Schema.Struct({
    cursor: Schema.optionalKey(Schema.String),
    limit: Schema.optionalKey(Schema.FiniteFromString),
}), [Schema.Record(Schema.String, Runtime.Data)]).pipe(Schema.decodeTo(Params));
export const encodeParams = Effect.fn("lexicon.encodeParams")(function* encodeParams(params) {
    return Query.entries(yield* Schema.decodeUnknownEffect(Query.Params)(yield* Schema.encodeEffect(ParamsFromQuery)(params)));
});
export const decodeParams = Effect.fn("lexicon.decodeParams")(function* decodeParams(entries) {
    return yield* Schema.decodeUnknownEffect(ParamsFromQuery)(Query.parameters(entries));
});
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "AuthRequired",
    "MailboxUnavailable",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: { limit: 100 },
    error: ErrorBody,
    input: Input,
    inputEncoding: "",
    method: "GET",
    nsid: "sh.mschf.ratking.identity.listNames",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.identity.listNames",
};
