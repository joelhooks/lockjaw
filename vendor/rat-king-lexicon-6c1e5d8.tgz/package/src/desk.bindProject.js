import { Schema } from "effect";
import * as Runtime from "./runtime.js";
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({
    desk: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
    project: Runtime.lexString({ maxLength: 128, type: "string" }).check(Schema.isMinLength(1)),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Schema.StructWithRest(Schema.Struct({
    project: Runtime.lexString({ maxLength: 128, type: "string" }),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "AuthRequired",
    "Forbidden",
    "ProjectConflict",
    "MailboxUnavailable",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.desk.bindProject",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.desk.bindProject",
};
