import { Effect, Schema } from "effect";
import * as Query from "./query.js";
import * as RuntimeLease from "./runtime.lease.js";
import * as Runtime from "./runtime.js";
export const Params = Schema.StructWithRest(Schema.Struct({
    did: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Input = Schema.Undefined;
export const Output = Schema.StructWithRest(Schema.Struct({ lease: RuntimeLease.Main }), [Schema.Record(Schema.String, Runtime.Data)]);
export const ParamsFromQuery = Schema.StructWithRest(Schema.Struct({ did: Schema.String }), [Schema.Record(Schema.String, Runtime.Data)]).pipe(Schema.decodeTo(Params));
export const encodeParams = Effect.fn("lexicon.encodeParams")(function* encodeParams(params) {
    return Query.entries(yield* Schema.decodeUnknownEffect(Query.Params)(yield* Schema.encodeEffect(ParamsFromQuery)(params)));
});
export const decodeParams = Effect.fn("lexicon.decodeParams")(function* decodeParams(entries) {
    return yield* Schema.decodeUnknownEffect(ParamsFromQuery)(Query.parameters(entries));
});
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "AuthRequired",
    "Forbidden",
    "LeaseNotFound",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "",
    method: "GET",
    nsid: "sh.mschf.ratking.runtime.resolveLease",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.runtime.resolveLease",
};
