import { Context, Effect, Layer, Schema } from "effect";
import * as PutDidDocument from "./admin.putDidDocument.js";
import * as GetPreferences from "./attention.getPreferences.js";
import * as GetStatus from "./attention.getStatus.js";
import * as PutPreferences from "./attention.putPreferences.js";
import * as PutStatus from "./attention.putStatus.js";
import { MailboxHandlers } from "./mailbox-handlers.js";
import * as Ack from "./mailbox.ack.js";
import * as Deliver from "./mailbox.deliver.js";
import * as List from "./mailbox.list.js";
import * as Send from "./mailbox.send.js";
import * as AcquireLease from "./runtime.acquireLease.js";
import * as ReleaseLease from "./runtime.releaseLease.js";
import * as RenewLease from "./runtime.renewLease.js";
import * as ResolveLease from "./runtime.resolveLease.js";
import * as Runtime from "./runtime.js";
import { XrpcFailure } from "./xrpc-failure.js";
export class MailboxServer extends Context.Service()("@rat-king/lexicon/MailboxServer") {
}
const encodeFailure = Effect.fn("lexicon.encodeFailure")(function* encodeFailure(failure) {
    const body = yield* Schema.encodeEffect(Runtime.XrpcErrorBody)(failure.message === undefined
        ? { error: failure.error }
        : { error: failure.error, message: failure.message });
    return { body, kind: "json", status: failure.status };
});
const validateRoute = (request, nsid, method) => request.nsid === nsid && request.method === method
    ? Effect.void
    : Effect.fail(new XrpcFailure({
        error: "InvalidRequest",
        response: { error: "InvalidRequest" },
        status: 400,
    }));
export const serverLayer = Layer.effect(MailboxServer, Effect.gen(function* serverLayer() {
    const handlers = yield* MailboxHandlers;
    const send = {
        handle: Effect.fn("lexicon.route.send")(function* route(request) {
            yield* validateRoute(request, Send.Method.nsid, Send.Method.method);
            const input = yield* Schema.decodeUnknownEffect(Send.Input)(request.input);
            const output = yield* handlers.send(input);
            return {
                body: yield* Schema.encodeEffect(Send.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: Send.Method.method,
        nsid: Send.Method.nsid,
        path: Send.Method.path,
    };
    const ack = {
        handle: Effect.fn("lexicon.route.ack")(function* route(request) {
            yield* validateRoute(request, Ack.Method.nsid, Ack.Method.method);
            const input = yield* Schema.decodeUnknownEffect(Ack.Input)(request.input);
            const output = yield* handlers.ack(input);
            return {
                body: yield* Schema.encodeEffect(Ack.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: Ack.Method.method,
        nsid: Ack.Method.nsid,
        path: Ack.Method.path,
    };
    const list = {
        handle: Effect.fn("lexicon.route.list")(function* route(request) {
            yield* validateRoute(request, List.Method.nsid, List.Method.method);
            const params = yield* Schema.decodeUnknownEffect(List.Params)(request.params);
            const output = yield* handlers.list(params);
            return {
                body: yield* Schema.encodeEffect(List.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: List.Method.method,
        nsid: List.Method.nsid,
        path: List.Method.path,
    };
    const acquireLease = {
        handle: Effect.fn("lexicon.route.acquireLease")(function* route(request) {
            yield* validateRoute(request, AcquireLease.Method.nsid, AcquireLease.Method.method);
            const input = yield* Schema.decodeUnknownEffect(AcquireLease.Input)(request.input);
            const output = yield* handlers.acquireLease(input);
            return {
                body: yield* Schema.encodeEffect(AcquireLease.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: AcquireLease.Method.method,
        nsid: AcquireLease.Method.nsid,
        path: AcquireLease.Method.path,
    };
    const renewLease = {
        handle: Effect.fn("lexicon.route.renewLease")(function* route(request) {
            yield* validateRoute(request, RenewLease.Method.nsid, RenewLease.Method.method);
            const input = yield* Schema.decodeUnknownEffect(RenewLease.Input)(request.input);
            const output = yield* handlers.renewLease(input);
            return {
                body: yield* Schema.encodeEffect(RenewLease.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: RenewLease.Method.method,
        nsid: RenewLease.Method.nsid,
        path: RenewLease.Method.path,
    };
    const releaseLease = {
        handle: Effect.fn("lexicon.route.releaseLease")(function* route(request) {
            yield* validateRoute(request, ReleaseLease.Method.nsid, ReleaseLease.Method.method);
            const input = yield* Schema.decodeUnknownEffect(ReleaseLease.Input)(request.input);
            const output = yield* handlers.releaseLease(input);
            yield* Schema.encodeEffect(ReleaseLease.Output)(output);
            return { body: "", kind: "text", status: 204 };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: ReleaseLease.Method.method,
        nsid: ReleaseLease.Method.nsid,
        path: ReleaseLease.Method.path,
    };
    const resolveLease = {
        handle: Effect.fn("lexicon.route.resolveLease")(function* route(request) {
            yield* validateRoute(request, ResolveLease.Method.nsid, ResolveLease.Method.method);
            const params = yield* Schema.decodeUnknownEffect(ResolveLease.Params)(request.params);
            const output = yield* handlers.resolveLease(params);
            return {
                body: yield* Schema.encodeEffect(ResolveLease.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: ResolveLease.Method.method,
        nsid: ResolveLease.Method.nsid,
        path: ResolveLease.Method.path,
    };
    const deliver = {
        handle: Effect.fn("lexicon.route.deliver")(function* route(request) {
            yield* validateRoute(request, Deliver.Method.nsid, Deliver.Method.method);
            const input = yield* Schema.decodeUnknownEffect(Deliver.Input)(request.input);
            const output = yield* handlers.deliver(input);
            return {
                body: yield* Schema.encodeEffect(Deliver.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: Deliver.Method.method,
        nsid: Deliver.Method.nsid,
        path: Deliver.Method.path,
    };
    const putDidDocument = {
        handle: Effect.fn("lexicon.route.putDidDocument")(function* route(request) {
            yield* validateRoute(request, PutDidDocument.Method.nsid, PutDidDocument.Method.method);
            const input = yield* Schema.decodeUnknownEffect(PutDidDocument.Input)(request.input);
            const output = yield* handlers.putDidDocument(input);
            return {
                body: yield* Schema.encodeEffect(PutDidDocument.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: PutDidDocument.Method.method,
        nsid: PutDidDocument.Method.nsid,
        path: PutDidDocument.Method.path,
    };
    const getPreferences = {
        handle: Effect.fn("lexicon.route.getPreferences")(function* route(request) {
            yield* validateRoute(request, GetPreferences.Method.nsid, GetPreferences.Method.method);
            const params = yield* Schema.decodeUnknownEffect(GetPreferences.Params)(request.params);
            const output = yield* handlers.getPreferences(params);
            return {
                body: yield* Schema.encodeEffect(GetPreferences.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: GetPreferences.Method.method,
        nsid: GetPreferences.Method.nsid,
        path: GetPreferences.Method.path,
    };
    const getStatus = {
        handle: Effect.fn("lexicon.route.getStatus")(function* route(request) {
            yield* validateRoute(request, GetStatus.Method.nsid, GetStatus.Method.method);
            const params = yield* Schema.decodeUnknownEffect(GetStatus.Params)(request.params);
            const output = yield* handlers.getStatus(params);
            return {
                body: yield* Schema.encodeEffect(GetStatus.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: GetStatus.Method.method,
        nsid: GetStatus.Method.nsid,
        path: GetStatus.Method.path,
    };
    const putPreferences = {
        handle: Effect.fn("lexicon.route.putPreferences")(function* route(request) {
            yield* validateRoute(request, PutPreferences.Method.nsid, PutPreferences.Method.method);
            const input = yield* Schema.decodeUnknownEffect(PutPreferences.Input)(request.input);
            const output = yield* handlers.putPreferences(input);
            return {
                body: yield* Schema.encodeEffect(PutPreferences.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: PutPreferences.Method.method,
        nsid: PutPreferences.Method.nsid,
        path: PutPreferences.Method.path,
    };
    const putStatus = {
        handle: Effect.fn("lexicon.route.putStatus")(function* route(request) {
            yield* validateRoute(request, PutStatus.Method.nsid, PutStatus.Method.method);
            const input = yield* Schema.decodeUnknownEffect(PutStatus.Input)(request.input);
            const output = yield* handlers.putStatus(input);
            return {
                body: yield* Schema.encodeEffect(PutStatus.Output)(output),
                kind: "json",
                status: 200,
            };
        }, Effect.catchTag("XrpcFailure", encodeFailure)),
        method: PutStatus.Method.method,
        nsid: PutStatus.Method.nsid,
        path: PutStatus.Method.path,
    };
    return MailboxServer.of({
        routes: new Map([
            [getPreferences.path, getPreferences],
            [getStatus.path, getStatus],
            [putPreferences.path, putPreferences],
            [putStatus.path, putStatus],
            [acquireLease.path, acquireLease],
            [renewLease.path, renewLease],
            [releaseLease.path, releaseLease],
            [resolveLease.path, resolveLease],
            [deliver.path, deliver],
            [putDidDocument.path, putDidDocument],
            [send.path, send],
            [ack.path, ack],
            [list.path, list],
        ]),
    });
}));
