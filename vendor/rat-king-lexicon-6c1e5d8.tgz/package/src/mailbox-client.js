import { Context, Effect, Layer, Result, Schema } from "effect";
import * as PutDidDocument from "./admin.putDidDocument.js";
import * as GetPreferences from "./attention.getPreferences.js";
import * as GetStatus from "./attention.getStatus.js";
import * as PutPreferences from "./attention.putPreferences.js";
import * as PutStatus from "./attention.putStatus.js";
import * as Ack from "./mailbox.ack.js";
import * as Deliver from "./mailbox.deliver.js";
import * as List from "./mailbox.list.js";
import * as Send from "./mailbox.send.js";
import * as AcquireLease from "./runtime.acquireLease.js";
import * as ReleaseLease from "./runtime.releaseLease.js";
import * as RenewLease from "./runtime.renewLease.js";
import * as ResolveLease from "./runtime.resolveLease.js";
import * as Runtime from "./runtime.js";
import { Transport } from "./transport.js";
import { XrpcFailure } from "./xrpc-failure.js";
const responseBody = Effect.fn("lexicon.responseBody")(function* responseBody(response) {
    if (response.kind !== "json") {
        return yield* new XrpcFailure({
            error: "NonJsonResponse",
            response: response.body,
            status: response.status,
        });
    }
    if (response.status < 200 || response.status >= 300) {
        const result = yield* Schema.decodeUnknownEffect(Runtime.XrpcErrorBody)(response.body).pipe(Effect.result);
        if (Result.isSuccess(result)) {
            return yield* new XrpcFailure({
                error: result.success.error,
                status: response.status,
                ...(result.success.message === undefined
                    ? { response: result.success }
                    : { message: result.success.message, response: result.success }),
            });
        }
        return yield* new XrpcFailure({
            error: "InvalidErrorResponse",
            response: { body: response.body },
            status: response.status,
        });
    }
    return response.body;
});
export class MailboxClient extends Context.Service()("@rat-king/lexicon/MailboxClient") {
}
export const clientLayer = Layer.effect(MailboxClient, Effect.gen(function* clientLayer() {
    const transport = yield* Transport;
    return MailboxClient.of({
        ack: Effect.fn("lexicon.ack")(function* invoke(input) {
            const body = yield* Schema.encodeEffect(Ack.Input)(input);
            const response = yield* transport.request({
                input: body,
                method: Ack.Method.method,
                nsid: Ack.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(Ack.Output)(yield* responseBody(response));
        }),
        acquireLease: Effect.fn("lexicon.acquireLease")(function* invoke(input) {
            const encoded = yield* Schema.encodeEffect(AcquireLease.Input)(input);
            const response = yield* transport.request({
                input: encoded,
                method: AcquireLease.Method.method,
                nsid: AcquireLease.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(AcquireLease.Output)(yield* responseBody(response));
        }),
        deliver: Effect.fn("lexicon.deliver")(function* invoke(input) {
            const encoded = yield* Schema.encodeEffect(Deliver.Input)(input);
            const response = yield* transport.request({
                input: encoded,
                method: Deliver.Method.method,
                nsid: Deliver.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(Deliver.Output)(yield* responseBody(response));
        }),
        getPreferences: Effect.fn("lexicon.getPreferences")(function* invoke(params) {
            const encoded = yield* Schema.encodeEffect(GetPreferences.Params)(params);
            const response = yield* transport.request({
                input: undefined,
                method: GetPreferences.Method.method,
                nsid: GetPreferences.Method.nsid,
                params: encoded,
            });
            return yield* Schema.decodeUnknownEffect(GetPreferences.Output)(yield* responseBody(response));
        }),
        getStatus: Effect.fn("lexicon.getStatus")(function* invoke(params) {
            const encoded = yield* Schema.encodeEffect(GetStatus.Params)(params);
            const response = yield* transport.request({
                input: undefined,
                method: GetStatus.Method.method,
                nsid: GetStatus.Method.nsid,
                params: encoded,
            });
            return yield* Schema.decodeUnknownEffect(GetStatus.Output)(yield* responseBody(response));
        }),
        list: Effect.fn("lexicon.list")(function* invoke(params) {
            const encoded = yield* Schema.encodeEffect(List.Params)({
                ...List.Method.defaults,
                ...params,
            });
            const response = yield* transport.request({
                input: undefined,
                method: List.Method.method,
                nsid: List.Method.nsid,
                params: encoded,
            });
            return yield* Schema.decodeUnknownEffect(List.Output)(yield* responseBody(response));
        }),
        putDidDocument: Effect.fn("lexicon.putDidDocument")(function* invoke(input) {
            const encoded = yield* Schema.encodeEffect(PutDidDocument.Input)(input);
            const response = yield* transport.request({
                input: encoded,
                method: PutDidDocument.Method.method,
                nsid: PutDidDocument.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(PutDidDocument.Output)(yield* responseBody(response));
        }),
        putPreferences: Effect.fn("lexicon.putPreferences")(function* invoke(input) {
            const encoded = yield* Schema.encodeEffect(PutPreferences.Input)(input);
            const response = yield* transport.request({
                input: encoded,
                method: PutPreferences.Method.method,
                nsid: PutPreferences.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(PutPreferences.Output)(yield* responseBody(response));
        }),
        putStatus: Effect.fn("lexicon.putStatus")(function* invoke(input) {
            const encoded = yield* Schema.encodeEffect(PutStatus.Input)(input);
            const response = yield* transport.request({
                input: encoded,
                method: PutStatus.Method.method,
                nsid: PutStatus.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(PutStatus.Output)(yield* responseBody(response));
        }),
        releaseLease: Effect.fn("lexicon.releaseLease")(function* invoke(input) {
            const encoded = yield* Schema.encodeEffect(ReleaseLease.Input)(input);
            const response = yield* transport.request({
                input: encoded,
                method: ReleaseLease.Method.method,
                nsid: ReleaseLease.Method.nsid,
                params: undefined,
            });
            if (response.status === 204 &&
                response.kind === "text" &&
                response.body === "") {
                const output = undefined;
                return yield* Schema.decodeEffect(ReleaseLease.Output)(output);
            }
            return yield* Schema.decodeUnknownEffect(ReleaseLease.Output)(yield* responseBody(response));
        }),
        renewLease: Effect.fn("lexicon.renewLease")(function* invoke(input) {
            const encoded = yield* Schema.encodeEffect(RenewLease.Input)(input);
            const response = yield* transport.request({
                input: encoded,
                method: RenewLease.Method.method,
                nsid: RenewLease.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(RenewLease.Output)(yield* responseBody(response));
        }),
        resolveLease: Effect.fn("lexicon.resolveLease")(function* invoke(params) {
            const encoded = yield* Schema.encodeEffect(ResolveLease.Params)({
                ...ResolveLease.Method.defaults,
                ...params,
            });
            const response = yield* transport.request({
                input: undefined,
                method: ResolveLease.Method.method,
                nsid: ResolveLease.Method.nsid,
                params: encoded,
            });
            return yield* Schema.decodeUnknownEffect(ResolveLease.Output)(yield* responseBody(response));
        }),
        send: Effect.fn("lexicon.send")(function* invoke(input) {
            const body = yield* Schema.encodeEffect(Send.Input)(input);
            const response = yield* transport.request({
                input: body,
                method: Send.Method.method,
                nsid: Send.Method.nsid,
                params: undefined,
            });
            return yield* Schema.decodeUnknownEffect(Send.Output)(yield* responseBody(response));
        }),
    });
}));
