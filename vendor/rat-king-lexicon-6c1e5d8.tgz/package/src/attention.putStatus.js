import { Schema } from "effect";
import * as AttentionStatus from "./attention.status.js";
import * as Runtime from "./runtime.js";
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({
    did: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
    keyId: Runtime.lexString({ type: "string" }),
    signature: Runtime.Bytes.check(Schema.makeFilter((value) => value.length >= 0 && value.length <= 9_007_199_254_740_991, { expected: "byte length constraints" })),
    status: AttentionStatus.Main,
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Schema.StructWithRest(Schema.Struct({ status: AttentionStatus.Main }), [Schema.Record(Schema.String, Runtime.Data)]);
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "AuthRequired",
    "DelegateCycle",
    "DelegateNotFound",
    "DelegateSelf",
    "Forbidden",
    "InvalidRequest",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.attention.putStatus",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.attention.putStatus",
};
