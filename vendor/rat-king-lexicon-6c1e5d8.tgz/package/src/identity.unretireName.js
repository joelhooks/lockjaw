import { Schema } from "effect";
import * as Runtime from "./runtime.js";
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({
    name: Runtime.lexString({ maxLength: 128, type: "string" }),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Schema.StructWithRest(Schema.Struct({
    cleared: Schema.Boolean,
    did: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
    name: Runtime.lexString({ maxLength: 128, type: "string" }),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "InvalidName",
    "AuthRequired",
    "Forbidden",
    "NameReserved",
    "MailboxUnavailable",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.identity.unretireName",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.identity.unretireName",
};
