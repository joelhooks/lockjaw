import { Context } from "effect";
export class MailboxHandlers extends Context.Service()("@rat-king/lexicon/MailboxHandlers") {
}
