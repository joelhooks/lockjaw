import { Schema } from "effect";
import * as Runtime from "./runtime.js";
export const Reply = Schema.StructWithRest(Schema.Struct({
    messageId: Runtime.lexString({ maxLength: 64, type: "string" }),
    uri: Runtime.lexString({ maxLength: 512, type: "string" }),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({
    desk: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
    messageId: Runtime.lexString({ maxLength: 64, type: "string" }),
    uri: Runtime.lexString({ maxLength: 512, type: "string" }),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Reply;
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "AuthRequired",
    "Forbidden",
    "MailboxUnavailable",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.desk.rememberReply",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.desk.rememberReply",
};
