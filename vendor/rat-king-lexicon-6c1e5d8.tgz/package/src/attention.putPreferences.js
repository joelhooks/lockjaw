import { Schema } from "effect";
import * as AttentionPrefs from "./attention.prefs.js";
import * as Runtime from "./runtime.js";
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({
    did: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
    keyId: Runtime.lexString({ type: "string" }),
    prefs: AttentionPrefs.Main,
    signature: Runtime.Bytes.check(Schema.makeFilter((value) => value.length >= 0 && value.length <= 9_007_199_254_740_991, { expected: "byte length constraints" })),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Schema.StructWithRest(Schema.Struct({ prefs: AttentionPrefs.Main }), [Schema.Record(Schema.String, Runtime.Data)]);
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "AuthRequired",
    "Forbidden",
    "InvalidRequest",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.attention.putPreferences",
    output: Output,
    outputEncoding: "application/json",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.attention.putPreferences",
};
