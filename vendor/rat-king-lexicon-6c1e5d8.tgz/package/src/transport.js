import { Context } from "effect";
export class Transport extends Context.Service()("@rat-king/lexicon/Transport") {
}
