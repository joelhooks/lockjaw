import { Schema } from "effect";
import * as Runtime from "./runtime.js";
export const Params = Schema.Undefined;
export const Input = Schema.StructWithRest(Schema.Struct({
    did: Runtime.lexString({ format: "did", type: "string" }).pipe(Schema.brand("Lexicon:did")),
    generation: Schema.Int.check(Schema.isGreaterThanOrEqualTo(1), Schema.isLessThanOrEqualTo(9_007_199_254_740_991)),
    leaseId: Runtime.lexString({ format: "tid", type: "string" }).pipe(Schema.brand("Lexicon:tid")),
}), [Schema.Record(Schema.String, Runtime.Data)]);
export const Output = Schema.Undefined;
export const ErrorBody = Runtime.XrpcErrorBody;
export const KnownErrors = [
    "InvalidRequest",
    "AuthRequired",
    "Forbidden",
    "LeaseMismatch",
];
export const isKnownError = (value) => KnownErrors.some((name) => name === value);
export const Method = {
    defaults: {},
    error: ErrorBody,
    input: Input,
    inputEncoding: "application/json",
    method: "POST",
    nsid: "sh.mschf.ratking.runtime.releaseLease",
    output: Output,
    outputEncoding: "",
    params: Params,
    path: "/xrpc/sh.mschf.ratking.runtime.releaseLease",
};
