import { Context, Effect } from "effect";
import type { TrustFailure } from "./trust-failure.js";
export interface RunToken {
    readonly exp: number;
    readonly iat: number;
    readonly tokenHash: string;
}
declare const RunBinding_base: Context.ServiceClass<RunBinding, "ratking/RunBinding", {
    readonly claim: (run: string, tokenHash: string, workerDid: string, now: number) => Effect.Effect<"bound" | "match" | "compromised", TrustFailure>;
    readonly close: (run: string) => Effect.Effect<void, TrustFailure>;
    readonly open: (run: string, token: RunToken, now: number) => Effect.Effect<void, TrustFailure>;
}>;
export declare class RunBinding extends RunBinding_base {
}
export declare const makeMemoryRunBinding: () => Effect.Effect<{
    readonly claim: (run: string, tokenHash: string, workerDid: string, now: number) => Effect.Effect<"bound" | "match" | "compromised", TrustFailure>;
    readonly close: (run: string) => Effect.Effect<void, TrustFailure>;
    readonly open: (run: string, token: RunToken, now: number) => Effect.Effect<void, TrustFailure>;
}, never, never>;
export {};
