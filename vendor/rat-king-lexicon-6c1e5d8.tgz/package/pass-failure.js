import { TrustFailure } from "./trust-failure.js";
export const refusal = (what, why, next) => new TrustFailure({ reason: `${what}; ${why}; ${next}` });
