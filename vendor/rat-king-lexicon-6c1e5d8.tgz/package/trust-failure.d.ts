import { Schema } from "effect";
declare const TrustFailure_base: Schema.Class<TrustFailure, Schema.TaggedStruct<"TrustFailure", {
    readonly reason: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class TrustFailure extends TrustFailure_base {
}
export {};
