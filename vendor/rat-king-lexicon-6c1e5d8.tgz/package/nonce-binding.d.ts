import { Context, Effect } from "effect";
import type { TrustFailure } from "./trust-failure.js";
export interface NonceIdentity {
    readonly run: string;
    readonly workerThumbprint: string;
}
declare const NonceBinding_base: Context.ServiceClass<NonceBinding, "ratking/NonceBinding", {
    readonly bind: (deskDid: string, nonce: string, identity: NonceIdentity, until: number) => Effect.Effect<"new" | "match" | "conflict", TrustFailure>;
}>;
export declare class NonceBinding extends NonceBinding_base {
}
export declare const makeMemoryNonceBinding: (now?: Effect.Effect<number, never, never>) => Effect.Effect<{
    readonly bind: (deskDid: string, nonce: string, identity: NonceIdentity, until: number) => Effect.Effect<"new" | "match" | "conflict", TrustFailure>;
}, never, never>;
export {};
