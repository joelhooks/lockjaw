import { Effect } from "effect";
import * as Base64Url from "effect/encoding/Base64Url";
import { refusal } from "./pass-failure.js";
const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const prime = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffffn;
const curveB = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604bn;
const mod = (value) => ((value % prime) + prime) % prime;
const power = (base, exponent) => {
    let result = 1n;
    let current = mod(base);
    let remaining = exponent;
    while (remaining > 0n) {
        if (remaining % 2n === 1n) {
            result = mod(result * current);
        }
        current = mod(current * current);
        remaining /= 2n;
    }
    return result;
};
const coordinate = (value) => {
    const hex = value.toString(16).padStart(64, "0");
    return Base64Url.encode(Uint8Array.from({ length: 32 }, (_, index) => Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16)));
};
const decode = (did) => {
    if (!/^did:key:z[1-9A-HJ-NP-Za-km-z]{48}$/u.test(did)) {
        throw new Error("not a canonical P-256 did:key");
    }
    let value = 0n;
    for (const char of did.slice(9)) {
        value = value * 58n + BigInt(alphabet.indexOf(char));
    }
    const hex = value.toString(16);
    if (hex.length !== 70 || !hex.startsWith("8024")) {
        throw new Error("not the P-256 multicodec");
    }
    const prefix = Number.parseInt(hex.slice(4, 6), 16);
    const x = BigInt(`0x${hex.slice(6)}`);
    if ((prefix !== 2 && prefix !== 3) || x >= prime) {
        throw new Error("invalid compressed P-256 point");
    }
    const square = mod(x * x * x - 3n * x + curveB);
    const root = power(square, (prime + 1n) / 4n);
    if (mod(root * root) !== square) {
        throw new Error("point is not on P-256");
    }
    const y = Number(root % 2n) === prefix % 2 ? root : prime - root;
    return { crv: "P-256", kty: "EC", x: coordinate(x), y: coordinate(y) };
};
export const decodeDidKey = (did) => Effect.try({
    catch: () => refusal("Key refused", "expected a canonical P-256 did:key", "generate a P-256 worker key and use its multibase DID"),
    try: () => decode(did),
});
