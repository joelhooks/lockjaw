import { Context } from "effect";
export class Signatures extends Context.Service()("ratking/Signatures") {
}
