import { Layer } from "effect";
import { Signatures } from "../trust.js";
export declare const signatures: Layer.Layer<Signatures, never, never>;
