import type { SigningKey } from "../passes.js";
import type { PublicKeyValue } from "../trust.js";
export declare const signingKey: (publicKey: PublicKeyValue, privateKey: Parameters<typeof crypto.subtle.sign>[1]) => SigningKey;
