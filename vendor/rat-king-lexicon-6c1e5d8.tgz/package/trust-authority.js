import { Context } from "effect";
export class TrustAuthority extends Context.Service()("ratking/TrustAuthority") {
}
