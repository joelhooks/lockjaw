import { Clock, Context, Effect } from "effect";
import { refusal } from "./pass-failure.js";
export class NonceBinding extends Context.Service()("ratking/NonceBinding") {
}
export const makeMemoryNonceBinding = (now = Clock.currentTimeMillis.pipe(Effect.map((ms) => ms / 1000))) => Effect.sync(() => {
    const bindings = new Map();
    return NonceBinding.of({
        bind: Effect.fn("NonceBinding.bind")(function* bindNonce(deskDid, nonce, identity, until) {
            const current = yield* now;
            if (!Number.isFinite(current) ||
                !Number.isFinite(until) ||
                until < current) {
                return yield* refusal("Nonce refused", "binding retention has expired", "obtain a fresh pass");
            }
            const key = JSON.stringify([deskDid, nonce]);
            const prior = bindings.get(key);
            if (prior !== undefined &&
                prior.until >= current &&
                (prior.identity.run !== identity.run ||
                    prior.identity.workerThumbprint !== identity.workerThumbprint)) {
                return "conflict";
            }
            bindings.set(key, {
                identity: { ...identity },
                until: Math.max(until, prior?.until ?? until),
            });
            return prior !== undefined && prior.until >= current
                ? "match"
                : "new";
        }),
    });
});
