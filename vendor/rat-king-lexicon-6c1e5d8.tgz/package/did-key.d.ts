import { Effect } from "effect";
export declare const decodeDidKey: (did: string) => Effect.Effect<{
    readonly crv: "P-256";
    readonly kty: "EC";
    readonly x: string;
    readonly y: string;
}, import("./trust-failure.js").TrustFailure, never>;
