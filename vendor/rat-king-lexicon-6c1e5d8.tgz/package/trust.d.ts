import { Effect, Schema } from "effect";
import type * as Runtime from "./src/runtime.js";
import { TrustAuthority } from "./trust-authority.js";
import { TrustFailure } from "./trust-failure.js";
import { Signatures } from "./trust-signatures.js";
export { TrustAuthority } from "./trust-authority.js";
export { TrustFailure } from "./trust-failure.js";
export { Signatures } from "./trust-signatures.js";
export type { Attestation, Issuer } from "./trust-authority.js";
export declare const PublicKey: Schema.Struct<{
    readonly crv: Schema.Literal<"P-256">;
    readonly kty: Schema.Literal<"EC">;
    readonly x: Schema.String;
    readonly y: Schema.String;
}>;
export type PublicKeyValue = typeof PublicKey.Type;
export declare const SignedInvite: Schema.Struct<{
    readonly keyId: Schema.String;
    readonly record: Schema.StructWithRest<Schema.Struct<{
        readonly $type: Schema.Literal<"sh.ratking.invite">;
        readonly allowFleetOutbound: Schema.Boolean;
        readonly createdAt: Schema.brand<Schema.String, "Lexicon:datetime">;
        readonly expiresAt: Schema.brand<Schema.String, "Lexicon:datetime">;
        readonly issuer: Schema.brand<Schema.String, "Lexicon:did">;
        readonly namespace: Schema.String;
        readonly ratePerMinute: Schema.Int;
        readonly recipients: Schema.$Array<Schema.String>;
        readonly subject: Schema.brand<Schema.String, "Lexicon:did">;
        readonly subjectKey: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Codec<Runtime.LexValue, Runtime.LexJson, never, never>>]>;
    readonly signature: Schema.String;
}>;
export type SignedInviteValue = typeof SignedInvite.Type;
export declare const SignedRevocation: Schema.Struct<{
    readonly keyId: Schema.String;
    readonly record: Schema.StructWithRest<Schema.Struct<{
        readonly $type: Schema.Literal<"sh.ratking.revocation">;
        readonly createdAt: Schema.brand<Schema.String, "Lexicon:datetime">;
        readonly invite: Schema.String;
        readonly issuer: Schema.brand<Schema.String, "Lexicon:did">;
    }>, readonly [Schema.$Record<Schema.String, Schema.Codec<Runtime.LexValue, Runtime.LexJson, never, never>>]>;
    readonly signature: Schema.String;
}>;
export type SignedRevocationValue = typeof SignedRevocation.Type;
export declare const Identity: Schema.StructWithRest<Schema.Struct<{
    readonly $type: Schema.Literal<"sh.ratking.identity">;
    readonly atprotoHandle: Schema.brand<Schema.String, "Lexicon:handle">;
    readonly audience: Schema.compose<Schema.Literal<"https://ratking.sh/mcp">, Schema.String>;
    readonly createdAt: Schema.brand<Schema.String, "Lexicon:datetime">;
    readonly expiresAt: Schema.brand<Schema.String, "Lexicon:datetime">;
    readonly handle: Schema.String;
    readonly publicKey: Schema.StructWithRest<Schema.Struct<{
        readonly crv: Schema.compose<Schema.Literal<"P-256">, Schema.String>;
        readonly kty: Schema.compose<Schema.Literal<"EC">, Schema.String>;
        readonly x: Schema.String;
        readonly y: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Codec<Runtime.LexValue, Runtime.LexJson, never, never>>]>;
    readonly subject: Schema.brand<Schema.String, "Lexicon:did">;
}>, readonly [Schema.$Record<Schema.String, Schema.Codec<Runtime.LexValue, Runtime.LexJson, never, never>>]>;
export type IdentityValue = typeof Identity.Type;
export declare const Credential: Schema.Struct<{
    readonly identity: Schema.Struct<{
        readonly keyId: Schema.String;
        readonly record: Schema.StructWithRest<Schema.Struct<{
            readonly $type: Schema.Literal<"sh.ratking.identity">;
            readonly atprotoHandle: Schema.brand<Schema.String, "Lexicon:handle">;
            readonly audience: Schema.compose<Schema.Literal<"https://ratking.sh/mcp">, Schema.String>;
            readonly createdAt: Schema.brand<Schema.String, "Lexicon:datetime">;
            readonly expiresAt: Schema.brand<Schema.String, "Lexicon:datetime">;
            readonly handle: Schema.String;
            readonly publicKey: Schema.StructWithRest<Schema.Struct<{
                readonly crv: Schema.compose<Schema.Literal<"P-256">, Schema.String>;
                readonly kty: Schema.compose<Schema.Literal<"EC">, Schema.String>;
                readonly x: Schema.String;
                readonly y: Schema.String;
            }>, readonly [Schema.$Record<Schema.String, Schema.Codec<Runtime.LexValue, Runtime.LexJson, never, never>>]>;
            readonly subject: Schema.brand<Schema.String, "Lexicon:did">;
        }>, readonly [Schema.$Record<Schema.String, Schema.Codec<Runtime.LexValue, Runtime.LexJson, never, never>>]>;
        readonly signature: Schema.String;
    }>;
    readonly invite: Schema.optionalKey<Schema.Struct<{
        readonly keyId: Schema.String;
        readonly record: Schema.StructWithRest<Schema.Struct<{
            readonly $type: Schema.Literal<"sh.ratking.invite">;
            readonly allowFleetOutbound: Schema.Boolean;
            readonly createdAt: Schema.brand<Schema.String, "Lexicon:datetime">;
            readonly expiresAt: Schema.brand<Schema.String, "Lexicon:datetime">;
            readonly issuer: Schema.brand<Schema.String, "Lexicon:did">;
            readonly namespace: Schema.String;
            readonly ratePerMinute: Schema.Int;
            readonly recipients: Schema.$Array<Schema.String>;
            readonly subject: Schema.brand<Schema.String, "Lexicon:did">;
            readonly subjectKey: Schema.String;
        }>, readonly [Schema.$Record<Schema.String, Schema.Codec<Runtime.LexValue, Runtime.LexJson, never, never>>]>;
        readonly signature: Schema.String;
    }>>;
}>;
export type CredentialValue = typeof Credential.Type;
export declare const Tier: Schema.Literals<readonly [0, 1, 2, 3, 4]>;
export declare const TierDescription: Schema.Struct<{
    readonly name: Schema.String;
    readonly proves: Schema.String;
    readonly tier: Schema.Literals<readonly [0, 1, 2, 3, 4]>;
}>;
export declare const tiers: readonly [{
    readonly name: "stranger";
    readonly proves: "Nothing. Read-only lobby access.";
    readonly tier: 0;
}, {
    readonly name: "self-keyed";
    readonly proves: "Key continuity, not the claimed DID or handle.";
    readonly tier: 1;
}, {
    readonly name: "domain";
    readonly proves: "An authority-verified atproto DID and handle binding.";
    readonly tier: 2;
}, {
    readonly name: "vouched";
    readonly proves: "A fleet member signed a scoped, unexpired invite.";
    readonly tier: 3;
}, {
    readonly name: "fleet";
    readonly proves: "An identity attested by the host issuer.";
    readonly tier: 4;
}];
export declare const signingBytes: (record: Runtime.LexValue, signingKeyId: string) => Uint8Array;
export declare const fingerprintBytes: (key: PublicKeyValue) => Uint8Array;
export declare const InviteScope: Schema.Struct<{
    readonly handle: Schema.String;
    readonly recipient: Schema.String;
    readonly subject: Schema.brand<Schema.String, "Lexicon:did">;
    readonly subjectKey: Schema.String;
}>;
export type InviteScopeValue = typeof InviteScope.Type;
export declare const VerifiedInvite: Schema.Struct<{
    readonly allowFleetOutbound: Schema.Boolean;
    readonly expiresAt: Schema.String;
    readonly fingerprint: Schema.String;
    readonly namespace: Schema.String;
    readonly ratePerMinute: Schema.Int;
    readonly recipients: Schema.$Array<Schema.String>;
    readonly tier: Schema.Literal<3>;
}>;
export type VerifiedInviteValue = typeof VerifiedInvite.Type;
export declare const verifyInvite: (signed: {
    readonly keyId: string;
    readonly record: {
        readonly [x: string]: Runtime.LexValue;
        readonly $type: "sh.ratking.invite";
        readonly allowFleetOutbound: boolean;
        readonly createdAt: string & import("effect/Brand").Brand<"Lexicon:datetime">;
        readonly expiresAt: string & import("effect/Brand").Brand<"Lexicon:datetime">;
        readonly issuer: string & import("effect/Brand").Brand<"Lexicon:did">;
        readonly namespace: string;
        readonly ratePerMinute: number;
        readonly recipients: readonly string[];
        readonly subject: string & import("effect/Brand").Brand<"Lexicon:did">;
        readonly subjectKey: string;
    };
    readonly signature: string;
}, scope: {
    readonly handle: string;
    readonly recipient: string;
    readonly subject: string & import("effect/Brand").Brand<"Lexicon:did">;
    readonly subjectKey: string;
}, now: number) => Effect.Effect<{
    readonly allowFleetOutbound: boolean;
    readonly expiresAt: string;
    readonly fingerprint: string;
    readonly namespace: string;
    readonly ratePerMinute: number;
    readonly recipients: readonly string[];
    readonly tier: 3;
}, TrustFailure, Signatures | TrustAuthority>;
export declare const TrustResult: Schema.Struct<{
    readonly fingerprint: Schema.NullOr<Schema.String>;
    readonly handle: Schema.NullOr<Schema.String>;
    readonly invite: Schema.NullOr<Schema.Struct<{
        readonly allowFleetOutbound: Schema.Boolean;
        readonly expiresAt: Schema.String;
        readonly fingerprint: Schema.String;
        readonly namespace: Schema.String;
        readonly ratePerMinute: Schema.Int;
        readonly recipients: Schema.$Array<Schema.String>;
        readonly tier: Schema.Literal<3>;
    }>>;
    readonly subject: Schema.NullOr<Schema.String>;
    readonly tier: Schema.Literals<readonly [0, 1, 2, 3, 4]>;
}>;
export type TrustResultValue = typeof TrustResult.Type;
export declare const stranger: {
    readonly fingerprint: string | null;
    readonly handle: string | null;
    readonly invite: {
        readonly allowFleetOutbound: boolean;
        readonly expiresAt: string;
        readonly fingerprint: string;
        readonly namespace: string;
        readonly ratePerMinute: number;
        readonly recipients: readonly string[];
        readonly tier: 3;
    } | null;
    readonly subject: string | null;
    readonly tier: 0 | 1 | 2 | 3 | 4;
};
export declare const whoami: (credential: {
    readonly identity: {
        readonly keyId: string;
        readonly record: {
            readonly [x: string]: Runtime.LexValue;
            readonly $type: "sh.ratking.identity";
            readonly atprotoHandle: string & import("effect/Brand").Brand<"Lexicon:handle">;
            readonly audience: "https://ratking.sh/mcp";
            readonly createdAt: string & import("effect/Brand").Brand<"Lexicon:datetime">;
            readonly expiresAt: string & import("effect/Brand").Brand<"Lexicon:datetime">;
            readonly handle: string;
            readonly publicKey: {
                readonly [x: string]: Runtime.LexValue;
                readonly crv: "P-256";
                readonly kty: "EC";
                readonly x: string;
                readonly y: string;
            };
            readonly subject: string & import("effect/Brand").Brand<"Lexicon:did">;
        };
        readonly signature: string;
    };
    readonly invite?: {
        readonly keyId: string;
        readonly record: {
            readonly [x: string]: Runtime.LexValue;
            readonly $type: "sh.ratking.invite";
            readonly allowFleetOutbound: boolean;
            readonly createdAt: string & import("effect/Brand").Brand<"Lexicon:datetime">;
            readonly expiresAt: string & import("effect/Brand").Brand<"Lexicon:datetime">;
            readonly issuer: string & import("effect/Brand").Brand<"Lexicon:did">;
            readonly namespace: string;
            readonly ratePerMinute: number;
            readonly recipients: readonly string[];
            readonly subject: string & import("effect/Brand").Brand<"Lexicon:did">;
            readonly subjectKey: string;
        };
        readonly signature: string;
    };
} | undefined, recipient: string, now: number) => Effect.Effect<{
    readonly fingerprint: string | null;
    readonly handle: string | null;
    readonly invite: {
        readonly allowFleetOutbound: boolean;
        readonly expiresAt: string;
        readonly fingerprint: string;
        readonly namespace: string;
        readonly ratePerMinute: number;
        readonly recipients: readonly string[];
        readonly tier: 3;
    } | null;
    readonly subject: string | null;
    readonly tier: 0 | 1 | 2 | 3 | 4;
}, TrustFailure, Signatures | TrustAuthority>;
