import { Schema } from "effect";
export declare const Turn: Schema.StructWithRest<Schema.Struct<{
    readonly $type: Schema.Literal<"sh.mschf.agentgraph.turn">;
    readonly agent: Schema.String;
    readonly at: Schema.brand<Schema.String, "Lexicon:datetime">;
    readonly generation: Schema.optionalKey<Schema.Int>;
    readonly reason: Schema.optionalKey<Schema.String>;
    readonly session: Schema.String;
    readonly state: Schema.compose<Schema.Literals<readonly ["working", "done", "blocked", "idle", "crashed"]>, Schema.String>;
    readonly stopReason: Schema.optionalKey<Schema.compose<Schema.Literals<readonly ["stop", "aborted", "error", "length"]>, Schema.String>>;
    readonly turnId: Schema.String;
    readonly version: Schema.compose<Schema.Literals<readonly ["0.1"]>, Schema.String>;
}>, readonly [Schema.$Record<Schema.String, Schema.Codec<import("./src/runtime.js").LexValue, import("./src/runtime.js").LexJson, never, never>>]>;
export type TurnValue = typeof Turn.Type;
export declare const signedTurn: (record: {
    readonly $type: string;
}, sender: string, verified: boolean) => import("effect/Option").Option<{
    readonly [x: string]: import("./src/runtime.js").LexValue;
    readonly $type: "sh.mschf.agentgraph.turn";
    readonly agent: string;
    readonly at: string & import("effect/Brand").Brand<"Lexicon:datetime">;
    readonly generation?: number;
    readonly reason?: string;
    readonly session: string;
    readonly state: "blocked" | "crashed" | "done" | "idle" | "working";
    readonly stopReason?: "aborted" | "error" | "length" | "stop";
    readonly turnId: string;
    readonly version: "0.1";
}>;
export declare const foldTurns: (records: readonly TurnValue[]) => ReadonlyMap<string, TurnValue>;
