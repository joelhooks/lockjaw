import { Context } from "effect";
import type { Effect } from "effect";
import type { TrustFailure } from "./trust-failure.js";
import type { PublicKeyValue, SignedRevocationValue } from "./trust.js";
export interface Issuer {
    readonly key: PublicKeyValue;
    readonly namespaces: readonly string[];
}
export interface Attestation {
    readonly subject: string;
    readonly handle: string;
    readonly fingerprint: string;
    readonly atprotoHandle: string;
    readonly tier: 2 | 4;
}
declare const TrustAuthority_base: Context.ServiceClass<TrustAuthority, "ratking/TrustAuthority", {
    readonly issuer: (did: string, keyId: string) => Effect.Effect<Issuer, TrustFailure>;
    readonly revocations: (issuer: string) => Effect.Effect<readonly SignedRevocationValue[], TrustFailure>;
    readonly identity: (keyId: string) => Effect.Effect<Attestation | undefined, TrustFailure>;
}>;
export declare class TrustAuthority extends TrustAuthority_base {
}
export {};
