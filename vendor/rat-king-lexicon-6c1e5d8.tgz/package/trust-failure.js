import { Schema } from "effect";
export class TrustFailure extends Schema.TaggedError()("TrustFailure", { reason: Schema.String }) {
}
